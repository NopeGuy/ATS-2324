package TP2;
public enum Dimensao {
    Pequeno,
    Medio,
    Grande
}
